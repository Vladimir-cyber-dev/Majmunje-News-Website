﻿namespace NoteApp.Controllers
{
    public class JwtConfiguration
    {
        public const string ValidIssuer = "BWZ-Rapperswil";
        public const string ValidAudience = "NoteApp Users";
        public const string IssuerSigningKey =
        "309D7E5F-914D-4FB9-8923-9732A4780840-72267CD5-FFC5-4393-BF4A-BFAA4F2CFE5F";
    }

}
